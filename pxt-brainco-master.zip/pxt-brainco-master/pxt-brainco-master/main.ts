
//% color=#FFFF00  block="brainco" blockId="brainco"
namespace brainco{
    const brainco_address = 0x10
    export enum MotorList {
        //% block="M1"
        M1,
        //% block="M2"
        M2,
        //% block="M3"
        M3,
        //% block="M4"
        M4
    }
    //% weight=88
    //% blockId=setMotorSpeed block="Set motor %motor speed to %speed\\%"
    //% speed.min=-100 speed.max=100
    export function setMotorSpeed(motor: MotorList, speed: number): void {
        let iic_buffer = pins.createBuffer(4);
        if (speed > 100) {
            speed = 100
        }
        else if(speed < -100){
            speed = -100
        }
        switch(motor){
            case MotorList.M1:
                iic_buffer[0] = 0x01;
                if(speed >= 0){
                    iic_buffer[1] = 0x01;
                }
                else{
                    iic_buffer[1] = 0x02;
                    speed = speed * -1
                }
                iic_buffer[2] = speed;
                iic_buffer[3] = 0;
                pins.i2cWriteBuffer(brainco_address, iic_buffer);
                break;
        }
    }
}